<!-- master.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/libs/flot/css/float-chart.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/style.min.css')); ?>" />
   
</head>
<body>   
       
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       
  
     
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/popper.js/dist/umd/popper.min.js')); ?>"></script>      
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js')); ?> "></script>
    <script src="<?php echo e(asset('assets/extra-libs/sparkline/sparkline.js')); ?>"></script>
    <script src="<?php echo e(asset('js/waves.js')); ?>"></script>   
    <script src="<?php echo e(asset('js/sidebarmenu.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/custom.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('assets/libs/flot/excanvas.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.js')); ?>"></script>  
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.pie.js')); ?>"></script>  
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.time.js')); ?>"></script>  
    <script src="<?php echo e(asset('assets/libs/flot/jquery.flot.crosshair.js')); ?>"></script>  
    <script src="<?php echo e(asset('assets/libs/flot.tooltip/js/jquery.flot.tooltip.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/pages/chart/chart-page-init.js')); ?>"></script>  
     
</body>
</html><?php /**PATH D:\xampp\htdocs\rajesh\library_management\resources\views/master.blade.php ENDPATH**/ ?>